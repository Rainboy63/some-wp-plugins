=== Translit For Search - Better Search for Inattentive Users ===
Contributors: OlSt
Donate link: https://...
Tags: search, relevance, better search, translit
Requires at least: 1.0
Tested up to: 1.0
Requires PHP: 5.6
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Расширение функциональности плагина поиска Relevanssi - поиск в прямой и, если ничего не найдено, автоматический поиск в обратной раскладке клавиатуры (русской или английской).

== Description ==

Расширение функциональности плагина поиска Relevanssi - поиск в прямой и, если ничего не найдено, в обратной раскладке клавиатуры (если термин поиска случайно введен при ошибочной раскладке, русской или английской).
Принцип: ищем в содержимом по введенному слову, если не находим ничего, ищем по слову в обратной раскладе (русская <--> english или english <--> русская), если находим, то выводим результаты. Если не находим опять ничего, то выводим оригинальное слово и что ничего не найдено.
Функция изменения параметров и запуска повторного поиска данного плагина прикрепляется к фильтру-хуку relevanssi_search_again плагина Relevanssi.

= Key features =

= Advanced features =

= Premium features =

= Translit For Search in Facebook =
You can find [Translit For Search in Facebook](https://www.facebook.com/...).

== Screenshots ==

== Installation ==

1. Install the plugin from the WordPress plugin screen.
2. Activate the plugin.
3. That's it!

= Uninstalling =
To uninstall the plugin remove the plugin using the normal WordPress plugin management tools (from the Plugins page, first Deactivate, then Delete).

== Frequently Asked Questions ==

= Knowledge Base =
You can find solutions and answers at the [Relevanssi Knowledge Base](https://www.relevanssi.com/category/knowledge-base/).

= Contextual help =

= Translit For Search doesn't work =

== Thanks ==
* Dmitry Stefantsov for extensive and relentless technical aid.

== Changelog ==
= 1.0 =
* All features and functions - new.